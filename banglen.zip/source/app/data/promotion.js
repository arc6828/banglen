import {Images} from '@config';
const PromotionData = [
  {
    id: '1',
    image: Images.room6,
    title1: 'Attaction & Activities',
    title2: 'Barcelona',
  },
  {
    id: '2',
    image: Images.room8,
    title1: 'Attaction & Activities',
    title2: 'Australia',
  },
  {
    id: '3',
    image: Images.room7,
    title1: 'Attaction & Activities',
    title2: 'Japan',
  },
  {
    id: '4',
    image: Images.room4,
    title1: 'Attaction & Activities',
    title2: 'Korean',
  },
  {
    id: '5',
    image: Images.room2,
    title1: 'Attaction & Activities',
    title2: 'Viet Nam',
  },
];

export {PromotionData};
