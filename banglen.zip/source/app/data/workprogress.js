const WorkProgressData = [
  {
    id: '1',
    step: 'Step 01',
    title: 'Getting Started',
    description: 'We’re National, the sunshine airline. Watch us shine',
  },
  {
    id: '2',
    step: 'Step 02',
    title: 'Privated Guide',
    description: 'We’re American Airlines, doing what we do best.',
  },
  {
    id: '3',
    step: 'Step 03',
    title: 'Support Cases',
    description: 'You are now free to move about the country.',
  },
];

export {WorkProgressData};
