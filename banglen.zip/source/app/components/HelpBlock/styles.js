import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  content: {alignItems: 'flex-start'},
  contentBlockCall: {
    flexDirection: 'row',
    marginTop: 10,
    alignItems: 'center',
  },
});
