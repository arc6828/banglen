if (self.CavalryLogger) { CavalryLogger.start_js(["6lP1c"]); }

__d("ServerTime",["InitialServerTime"],(function(a,b,c,d,e,f){d(b("InitialServerTime").serverTime);var g;function a(){return Date.now()-g}function c(){return g}function d(a){g=Date.now()-a}e.exports={getMillis:a,getOffsetMillis:c,update:d,get:a,getSkew:c}}),null);